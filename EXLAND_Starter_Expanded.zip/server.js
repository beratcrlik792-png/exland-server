const express=require("express"), http=require("http"), WebSocket=require("ws"), cors=require("cors");
const app=express(); app.use(cors()); app.use(express.json()); app.use(express.static("client"));
app.get("/health",(_,res)=>res.json({ok:true,game:"EXLAND",players:wss.clients.size}));
const server=http.createServer(app), wss=new WebSocket.Server({server});
const players=new Map();
function send(ws,data){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(data))}
function broadcast(data,except){const raw=JSON.stringify(data);for(const c of wss.clients)if(c!==except&&c.readyState===WebSocket.OPEN)c.send(raw)}
wss.on("connection",ws=>{
 let player=null;
 ws.on("message",raw=>{
  let m;try{m=JSON.parse(raw)}catch{return}
  if(m.type==="join"){
   const name=String(m.name||"").trim();
   if(!/^[a-zA-Z0-9_]{3,16}$/.test(name)){send(ws,{type:"error",message:"İsim 3-16 karakter olmalı; harf, sayı ve _ kullanılabilir."});return}
   if([...players.values()].some(p=>p.name.toLowerCase()===name.toLowerCase())){send(ws,{type:"error",message:"Bu ismi zaten başka birisi almış!"});return}
   player={id:Math.random().toString(36).slice(2),name,x:0,y:0,z:0,hp:100,score:0};players.set(ws,player);
   send(ws,{type:"welcome",you:player,players:[...players.values()]});broadcast({type:"joined",player},ws);return;
  }
  if(!player)return;
  if(m.type==="move"){player.x=Number(m.x)||0;player.y=Number(m.y)||0;player.z=Number(m.z)||0;broadcast({type:"moved",player},ws)}
  if(m.type==="shoot"&&m.target){for(const [sock,p] of players){if(p.id===m.target){p.hp-=25;if(p.hp<=0){p.hp=100;player.score++;broadcast({type:"respawn",player:p,killer:player.name})}else broadcast({type:"hit",player:p,damage:25});break}}}
 });
 ws.on("close",()=>{if(player){players.delete(ws);broadcast({type:"left",id:player.id})}});
});
const PORT=process.env.PORT||3000;server.listen(PORT,()=>console.log("EXLAND server listening on "+PORT));
