# EXLAND Starter + Character Creator

## Kurulum
1. ZIP'i açın ve içeriğini GitHub'daki `exland-server` deposuna yükleyin.
2. Render/Node hosting üzerinde `npm install` ve `npm start` komutlarını çalıştırın.
3. Uygulamayı HTTPS adresinden açın.

## İçerik
- Express + WebSocket başlangıç sunucusu
- Oyuncu adı benzersizlik kontrolü (bağlı oyuncular arasında)
- 50 ücretsiz kıyafet, 50 pantolon, 25 başlık ve aksesuar kataloğu
- Tarayıcıda yerel karakter seçimi kaydı
- Ateş, şarjör, eğilme, kapı ve mikrofon arayüzü

## Önemli prototip sınırları
Bu paket tam PUBG benzeri üretim oyunu değildir. Karakter önizlemesi şu anda CSS ile çizilmiş bir görsel prototiptir; katalogdaki kozmetikler ayrı 3D mesh/texture değildir. Silah/kapı/eğilme kontrolleri arayüz prototipidir; gerçek iskelet animasyon klipleri henüz eklenmemiştir. Mikrofon düğmesi cihazdan mikrofon izni alır fakat oyunculara ses iletmez. Gerçek sesli sohbet için WebRTC peer bağlantıları ve signaling gerekir. Sunucu örneği basit prototiptir; veritabanı, kalıcı hesaplar, güvenli matchmaking ve anti-cheat içermez.
